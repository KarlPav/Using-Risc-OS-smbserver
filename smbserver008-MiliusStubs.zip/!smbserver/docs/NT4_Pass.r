REGEDIT4

;Contributor:   Tim Small (tim.small@virgin.net)
;Updated:	20 August 1997
;Status:	Current
;
;Subject:	Registry file to enable plain text passwords in NT4-SP3 and later

[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Rdr\Parameters]
"EnablePlainTextPassword"=dword:00000001

